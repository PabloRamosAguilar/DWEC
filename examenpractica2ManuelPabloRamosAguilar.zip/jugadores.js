function mostrarJugadores(jugador) {
    if (jugador.length == 0) {
        document.getElementById("nombreJug").innerHTML = "";
        document.getElementById("posicionJug").innerHTML = "";
        document.getElementById("equipoJug").innerHTML = "";
        document.getElementById("paisJug").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var xmlDoc = this.responseXML;
                document.getElementById("nombreJug").innerHTML =
                    xmlDoc.getElementsByTagName("nombre")[0].childNodes[0].nodeValue;
                document.getElementById("posicionJug").innerHTML =
                    xmlDoc.getElementsByTagName("posicion")[0].childNodes[0].nodeValue;
                document.getElementById("equipoJug").innerHTML =
                    xmlDoc.getElementsByTagName("equipo")[0].childNodes[0].nodeValue;
                document.getElementById("paisJug").innerHTML =
                    xmlDoc.getElementsByTagName("pais")[0].childNodes[0].nodeValue;
                document.getElementById("golesJug").innerHTML =
                    xmlDoc.getElementsByTagName("goles")[0].childNodes[0].nodeValue;
            }
        };
        xmlhttp.open("GET", "servidor.php?jugador=" + jugador, true);
        xmlhttp.send();
    }
}