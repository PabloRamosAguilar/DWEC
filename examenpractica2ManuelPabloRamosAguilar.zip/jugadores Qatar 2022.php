<?php
$bd = new PDO('mysql:host=localhost;dbname=qatar2022;charset=utf8', 'dwes', 'abc123');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Jugadores Qatar 2022</title>
    <link type="text/css" rel="stylesheet" href="jugadores.css">
    <style>
        @import url('https://fonts.cdnfonts.com/css/qatar2022');

        * {
            font-family: 'Qatar2022', sans-serif;
        }
    </style>
    <script src="jugadores.js"></script>
</head>

<body>
    <header>
        <h2>Campeonato del Mundo QATAR - 2022</h2>
    </header>
    <div class="tabla">
        <table>
            <caption class="titulo">España</caption>
            <tbody>
                <tr>
                    <?php
                    $resultado = $bd->query('SELECT * FROM jugadores WHERE pais="España" ORDER BY 1 ASC');
                    $contador = 0;
                    while ($jugador = $resultado->fetch()) {
                        if ($contador != 0 && $contador % 4 == 0) {
                            echo "</tr>\n";
                            echo "<tr>\n";
                        }
                        echo '<td><input type="radio" onchange="mostrarJugadores(this.value)" name="jugador" id="' . $jugador['idJugador'] . '"';
                        echo ' value="' . $jugador['jugador'];
                        echo '"><label for="' . $jugador['idJugador'] . '">' . $jugador['jugador'] . '</label></td>' . "\n";
                        $contador++;
                    }
                    ?>
                </tr>
            </tbody>
        </table>
        <hr>
    </div>
    <div id="cuerpo">
        <h2>Datos del jugador</h2>
        Nombre Jugador : <p id="nombreJug"></p>
        Posición Jugador : <p id="posicionJug"></p>
        Equipo Jugador : <p id="equipoJug"></p>
        Pais Jugador : <p id="paisJug"></p>
        Goles Jugador : <p id="golesJug"></p>
    </div>
    </div>
    <footer>
        <p>Desarrollado por: Manuel Pablo Ramos Aguilar</p>
    </footer>
</body>

</html>