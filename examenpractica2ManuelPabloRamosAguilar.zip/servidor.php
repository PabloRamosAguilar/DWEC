<?php
// ejemplo4servidor.php
header('Content-Type: text/xml'); // Esta línea indica que la respuesta es XML
header("Cache-Control: no-cache, must-revalidate"); // Esta línea ayuda a que la respuesta no se incluya en caché
// Fecha caducada
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Esta línea ayuda a que la respuesta no se incluya en caché
$jugador = $_GET["jugador"];
$bd = new PDO('mysql:host=localhost;dbname=qatar2022;charset=utf8', 'dwes', 'abc123');
echo '<?xml version="1.0" encoding="ISO-8859-1"?>
<jugador>';
$consulta = $bd->prepare("SELECT jugador, posicion, equipo, pais, numeroGoles FROM jugadores J INNER JOIN goleadores G WHERE jugador = :jugador");
$consulta->execute(['jugador' => $_GET['jugador']]);
if ($jugadores = $consulta->fetch()) {
    if ($jugadores['numeroGoles'] == null) {
        echo "<nombre>" . $jugadores['jugador'] . "</nombre>";
        echo "<posicion>" . $jugadores['posicion'] . "</posicion>";
        echo "<equipo>" . $jugadores['equipo'] . "</equipo>";
        echo "<pais>" . $jugadores['pais'] . "</pais>";
        echo "<goles>" . $jugadores['numeroGoles'] . "</goles>";
    } else {
        echo "<nombre>" . $jugadores['jugador'] . "</nombre>";
        echo "<posicion>" . $jugadores['posicion'] . "</posicion>";
        echo "<equipo>" . $jugadores['equipo'] . "</equipo>";
        echo "<pais>" . $jugadores['pais'] . "</pais>";
        echo "<goles>" . "0" . "</goles>";
    }
}
echo "</jugador>";
