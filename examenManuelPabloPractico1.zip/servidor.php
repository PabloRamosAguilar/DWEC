<?php

$bd = new PDO('mysql:host=localhost;dbname=qatar2022;charset=utf8', 'dwes', 'abc123');

if (isset($_GET['pais'])) {
    echo '<ol>'; // Imprimimos opción vacía
    $consulta = $bd->prepare("SELECT jugador FROM jugadores WHERE pais = :pais");
    $consulta->execute(['pais' => $_GET['pais']]);
    while ($jugadores = $consulta->fetch()) {
        echo '<li>'. $jugadores['jugador'] . '</li>';
    }
    echo '</ol>';
} else {
    echo "NO hay jugadores";
}
